# random_colour
It generates random colour.
